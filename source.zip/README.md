# [Ddmine79](https://rkbokul1.github.io/Ddmin79_First_project/) 
This is a very low budget fiverr project.

## Project Details
1. Point existing Domain to new hosting.
2. cPanel clear and restore from past backup folder.
3. Redesign new UI using simple html, css and Bootstrap.
4. Added new shutterstock premium images in this project.

## live-site link [Click](https://www.pvp-cambodia.com/).

```bash
git add .
git commit -m"everything is okay"
git push
```


```

## Contributing

All code are keep in the developers github account for update and Future usese.
And Don't copy or clone any repository form this Github account.

## License

[Repository](https://github.com/rkbokul1/Ddmin79_First_project/)